import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const state={
    url:'118.190.112.59:8070',
    
//影院模块
	ruleForm:{
        cinemaCode:'',//影院编码
        cinemaName:'',//影院名称
        cinemAddress:'',//影院地址
        businessStatus:'',//营业状态
        cinemaContact:'',//影院联系人
        contactNumber:'',//联系人电话
        cinemaPostcode:'',//影院邮编
        cinemaFacsimile:'',//影院传真
        cinemaEmail:'',//影院邮箱
        screenCount:'',//影厅数量
        cinemas:'',
        corporation:''
    },
//影片模块
    synchronizationTime:'',//同步时间
    //同步操作
    synchradio:{
        syntableData:[],//同步数据数组
        totalCount:0,//数据条数
        currentPage:1,//当前页
    },
    //同步查询
    synch:{
        syntableData:[],//同步查询数据数组
        totalCount:0,//数据条数
        currentPage:1,//当前页
        startTime:'',
        endTime:'',
        filmName:'',
        filmCode:'',
    },
    //片库查询
    libra:{
        libtableData:[],//片库查询数据数组
        totalCount:0,//数据条数
        currentPage:1,//当前页
        startTime:'',
        endTime:'',
        filmName:'',
        filmCode:'',
    }
   
}

export default new Vuex.Store({
	state
	
})